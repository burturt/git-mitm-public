console.log("hello, world!")
process.exitCode = 1
